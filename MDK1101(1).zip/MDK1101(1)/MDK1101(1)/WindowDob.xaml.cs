﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MDK1101_1_
{
    
    /// <summary>
    /// Логика взаимодействия для WindowDob.xaml
    /// </summary>
    public partial class WindowDob : Window
    {
        public DataRowView rowView;
        MySqlConnection conn;
        public DataRowView DataRow;
        public DataRowView view;

        public WindowDob()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            this.Close();
            window.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {       
            conn = new MySqlConnection("server=127.0.0.1; uid=root; pwd=2007; database=petrov");
            conn.Open();
            MySqlCommand com = new MySqlCommand($"INSERT INTO Client(Nickname,Full_name,Age,Gender,Growth,Nationality, Data_of_birth, Weight, City) VALUES('{TextBox1.Text}', '{TextBox2.Text}', '{int.Parse(TextBox3.Text)}', '{TextBox4.Text}', '{TextBox5.Text}','{TextBox6.Text}','{TextBox7.Text}','{TextBox8.Text}','{TextBox9.Text}')", conn);
            com.ExecuteNonQuery();
            MessageBox.Show("Данные введены успешно, выполняется переход на списка. Будьте внимательны!");
                Window1 window2 = new Window1();
                this.Close();
                window2.ShowDialog();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
           
        } 
    }
}
