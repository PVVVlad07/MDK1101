﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MDK1101_1_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
