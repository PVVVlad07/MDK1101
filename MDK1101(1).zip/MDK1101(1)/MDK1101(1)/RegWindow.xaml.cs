﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MDK1101_1_
{
    /// <summary>
    /// Логика взаимодействия для RegWindow.xaml
    /// </summary>
    public partial class RegWindow : Window
    {
        MySqlConnection conn1;
        public DataRowView DataRow;
        public DataRowView view;
        public DataRowView rowView;
        public DataRowView data;
        public RegWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn1 = new MySqlConnection("server=127.0.0.1; user id=root; password =2007; database=petrov");
            conn1.Open();
            MySqlCommand com = new MySqlCommand("SELECT * FROM Account", conn1);
            MySqlDataReader reader = com.ExecuteReader();
            DataTable table1 = new DataTable();
            table1.Load(reader);
            DataGrid2.ItemsSource = table1.DefaultView;
        }
    }
}
