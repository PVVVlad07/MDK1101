﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySqlConnector;

namespace MDK1101_1_
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        MySqlConnection conn;
        public DataRowView DataRow;
        public DataRowView view;

        public Window3()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; user id=root; password =2007; database=petrov");
            conn.Open();
            MySqlCommand com = new MySqlCommand("SELECT * FROM Vstrechy", conn);
            MySqlDataReader reader = com.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            DataGrid3.ItemsSource = table.DefaultView;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            conn.Close();
        }
    }
}
