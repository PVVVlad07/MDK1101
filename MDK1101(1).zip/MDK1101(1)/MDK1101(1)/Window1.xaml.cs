﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySqlConnector;


namespace MDK1101_1_
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        MySqlConnection conn;
        public DataRowView DataRow;
        public DataRowView view;
        public DataRowView rowView;
        public DataRowView data;



        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn = new MySqlConnection("server=127.0.0.1; user id=root; password =2007; database=petrov");
            conn.Open();
            MySqlCommand com = new MySqlCommand("SELECT * FROM Client", conn);
            MySqlDataReader reader = com.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            DataGrid1.ItemsSource = table.DefaultView;

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            conn.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            WindowMenu4 window = new WindowMenu4();
            this.Close();
            window.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            WindowDob window = new WindowDob();
            this.Close();
            window.ShowDialog();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (DataGrid1.SelectedIndex != -1)
            {
                data = DataGrid1.SelectedItem as DataRowView;
                MySqlCommand command = new MySqlCommand($"DELETE FROM Client WHERE Nickname = '{data["Nickname"].ToString()}'", conn);
                command.ExecuteNonQuery();
                UpdateGrid();
            }
            else
            {
                MessageBox.Show("Выбирите нужного человека!");
            }
        }


        public void UpdateGrid()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM Client", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            DataGrid1.ItemsSource = dt.DefaultView;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

            if (DataGrid1.SelectedIndex != -1)
            {
                
                RedocttWindow window = new RedocttWindow();
                this.Close();
                window.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выбирите нужного человека!");
            }
           
        }
    }
    
}

