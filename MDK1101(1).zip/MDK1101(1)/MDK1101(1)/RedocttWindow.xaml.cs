﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MDK1101_1_
{

    /// <summary>
    /// Логика взаимодействия для RedocttWindow.xaml
    /// </summary>
    public partial class RedocttWindow : Window
    {
        public DataRowView rowView;
        MySqlConnection conn;
        public DataRowView DataRow;
        public DataRowView view;
        public RedocttWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            this.Close();
            window.ShowDialog();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TextBox1.Text = DataRow["Nickname"].ToString();
            TextBox2.Text = rowView["Full_name"].ToString();
            TextBox3.Text = rowView["Age,"].ToString();
            TextBox4.Text = rowView["Gender"].ToString();
            TextBox5.Text = rowView["Growth"].ToString();
            TextBox6.Text = rowView["Nationality"].ToString();
            TextBox7.Text = rowView["Data_of_birth"].ToString();
            TextBox8.Text = rowView["Weight"].ToString();
            TextBox9.Text = rowView["City"].ToString();
        }
    }
}
