﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для DobavWindow.xaml
    /// </summary>
    public partial class DobavWindow : Window
    {
        FbConnection conn;
        public DobavWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            this.Close();
            window.ShowDialog();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            conn = new FbConnection("server=localhost; uid=SYSDBA; password=masterkey; database=C:/Users/Vladislav/Desktop/mdk_1101_vs/PETROV.FDB");
            conn.Open();
            FbCommand command1 = new FbCommand($"INSERT INTO GRUZ_GRUZ_TRAIN(ID_GRUZA, NAME_GRUZ) VALUES('{textbox1.Text}', '{textbox2.Text}')", conn);
            command1.ExecuteNonQuery();
            MessageBox.Show("Данные введены успешно, выполняется переход на окно таблицы.");
            MainWindow window2 = new MainWindow();
            this.Close();
            window2.ShowDialog();


        }
    }
}
