﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для RedaktWindow.xaml
    /// </summary>
    public partial class RedaktWindow : Window
    {
        FbConnection conn;
        public DataRowView rowView;
        public RedaktWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            this.Close();
            window.ShowDialog();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            conn = new FbConnection("server=localhost; uid=SYSDBA; password=mastetkey; database=C:/Users/Vladislav/Desktop/mdk_1101_vs/PETROV.FDB");
            conn.Open();
            FbCommand command = new FbCommand($"UDPATE GRUZ_GRUZ_TRAIN SET ID_GRUZA = '{textbox1.Text}', NAME_GRUZ = '{textbox2.Text}", conn);
            command.ExecuteNonQuery();
            MessageBox.Show("Обновление выполнено! Переход на главное окно!");
            MainWindow window1 = new MainWindow();
            this.Close();
            window1.ShowDialog();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textbox1.Text = rowView["ID_GRUZA"].ToString();
            textbox2.Text = rowView["NAME_GRUZ"].ToString();
        }
    }
}
