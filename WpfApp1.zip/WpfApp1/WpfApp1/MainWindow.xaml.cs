﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FirebirdSql.Data.FirebirdClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        FbConnection conn;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn = new FbConnection("server=localhost;uid=SYSDBA;password=masterkey;database=C:/Users/Vladislav/Desktop/mdk_1101_vs/PETROV.FDB");
            conn.Open();
            FbCommand command = new FbCommand("SELECT * FROM GRUZ_GRUZ_TRAIN", conn);
            FbDataReader rea = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rea);
            GGT.ItemsSource = dt.DefaultView;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            Menu window = new Menu();
            this.Close();
            window.ShowDialog();

        }
    }
}
