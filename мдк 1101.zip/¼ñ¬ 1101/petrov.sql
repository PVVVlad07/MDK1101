-- MySQL dump 10.13  Distrib 5.7.25, for Win32 (AMD64)
--
-- Host: 10.20.5.135    Database: Petrov
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.8-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Result_vstrexh`
--

DROP TABLE IF EXISTS `Result_vstrexh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Result_vstrexh` (
  `Full_name` varchar(100) NOT NULL,
  `Result` enum('good','bad') NOT NULL,
  `Id_paryu` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_paryu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Result_vstrexh`
--

LOCK TABLES `Result_vstrexh` WRITE;
/*!40000 ALTER TABLE `Result_vstrexh` DISABLE KEYS */;
/*!40000 ALTER TABLE `Result_vstrexh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `Nickname` varchar(100) NOT NULL,
  `Full_name` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` enum('M','F') NOT NULL,
  `Growth` int(3) DEFAULT NULL,
  `Nationality` varchar(50) DEFAULT NULL,
  `Data_of_birth` varchar(50) NOT NULL,
  `Weight` int(3) DEFAULT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`Nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES ('Alenka','Власова Алёна Артёмовна',30,'F',170,'Russian','10.04.1994',62,'Moscow'),('AnyaL','Лыкова Анна Данииловна',30,'F',162,'Russian','23.02.2000',58,'Moscow'),('Arinka_vitamika','Нестерова Арина Дмитриевна',21,'F',166,'Russian','09.12.2003',57,'Moscow'),('GromD','Громов Давид Андреевич',21,'M',178,'Russian','03.08.2003',75,'Moscow'),('Sasha71','Соколов Александр Ильич',54,'M',190,'Russian','05.03.1971',94,'Mosсow'),('VasyaN1','Лаврентьев Василий Петрович',33,'M',178,'Russian','16.01.1992',87,'Mosсow');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vstrechy`
--

DROP TABLE IF EXISTS `vstrechy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vstrechy` (
  `id_vstrechy` varchar(100) NOT NULL,
  `Nickname` varchar(100) NOT NULL,
  `Id_paryu` varchar(100) NOT NULL,
  PRIMARY KEY (`id_vstrechy`),
  KEY `vstrechy` (`Nickname`),
  KEY `Id_paryu` (`Id_paryu`),
  CONSTRAINT `vstrechy` FOREIGN KEY (`Nickname`) REFERENCES `client` (`Nickname`),
  CONSTRAINT `vstrechy_ibfk_1` FOREIGN KEY (`Id_paryu`) REFERENCES `Result_vstrexh` (`Id_paryu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vstrechy`
--

LOCK TABLES `vstrechy` WRITE;
/*!40000 ALTER TABLE `vstrechy` DISABLE KEYS */;
/*!40000 ALTER TABLE `vstrechy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-27 13:53:13
