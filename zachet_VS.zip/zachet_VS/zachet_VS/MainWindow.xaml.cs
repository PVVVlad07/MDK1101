﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using FirebirdSql.Data.FirebirdClient;


namespace zachet_VS
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        FbConnection conn;
        DataRowView dat;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conn = new FbConnection("server=localhost;uid=SYSDBA;password=masterkey;database=C:/Users/Vladislav/Desktop/Zavhet/PETROV.FDB");
            conn.Open();
            FbCommand command = new FbCommand("SELECT * FROM V_SREDNIY_BAL", conn);
            FbDataReader rea = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rea);
            SB.ItemsSource = dt.DefaultView;
        }
    }
}
